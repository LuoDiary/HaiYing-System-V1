from setuptools import setup

package_name = 'arm_trajectory_ctrl'

setup(
    name=package_name,
    version='0.0.0',
    packages=[
        package_name,
        package_name + ".scripts"
    ],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='chenxiaoyu',
    maintainer_email='chenxiaoyu@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'trajectory_node = arm_trajectory_ctrl.scripts.trajectory_node:main',
            'mission_fsm_node = arm_trajectory_ctrl.scripts.mission_fsm_node:main',
        ],
    },
)
