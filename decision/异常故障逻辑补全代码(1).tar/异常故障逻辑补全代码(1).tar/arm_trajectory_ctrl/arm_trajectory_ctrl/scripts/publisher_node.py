import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PointStamped

class TargetPublisher(Node):
    def __init__(self):
        super().__init__('target_publisher')
        # 创建话题：/arm_target_point，消息类型PointStamped（目标三维坐标）
        self.publisher_ = self.create_publisher(PointStamped, '/arm_target_point', 10)
        timer_period = 2.0  # 2秒发一条测试数据
        self.timer = self.create_timer(timer_period, self.timer_callback)
        self.count = 0

    def timer_callback(self):
        msg = PointStamped()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = "base_link"
        # 模拟目标三维坐标
        msg.point.x = 0.3
        msg.point.y = 0.2
        msg.point.z = 0.4
        self.publisher_.publish(msg)
        self.get_logger().info(f'发布目标坐标: x={msg.point.x},y={msg.point.y},z={msg.point.z}')
        self.count += 1

def main(args=None):
    rclpy.init(args=args)
    node = TargetPublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

