import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PointStamped

class TargetSubscriber(Node):
    def __init__(self):
        super().__init__('target_subscriber')
        self.subscription = self.create_subscription(
            PointStamped,
            '/arm_target_point',
            self.listener_callback,
            10)
        self.subscription

    def listener_callback(self, msg):
        self.get_logger().info(f'收到目标点位：X={msg.point.x:.2f}, Y={msg.point.y:.2f}, Z={msg.point.z:.2f}')
        # 后续可以在这里调用轨迹规划函数

def main(args=None):
    rclpy.init(args=args)
    node = TargetSubscriber()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

