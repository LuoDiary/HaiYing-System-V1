#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Pose
from moveit_msgs.msg import MoveItErrorCodes
from tf2_ros import TransformListener, Buffer

class ArmTrajectoryNode(Node):
    def __init__(self):
        super().__init__("arm_trajectory_node")
        self.get_logger().info("机械臂轨迹控制节点启动成功")
        # TF坐标变换缓存，对接视觉YOLO缺陷坐标
        self.tf_buf = Buffer()
        self.tf_listener = TransformListener(self.tf_buf, self)
        # 3秒后自动执行巡检轨迹
        self.run_timer = self.create_timer(3.0, self.execute_inspect_path)

    def execute_inspect_path(self):
        # 定义风机缺陷检测目标末端位姿
        target_pose = Pose()
        target_pose.position.x = 0.30
        target_pose.position.y = 0.00
        target_pose.position.z = 0.22
        target_pose.orientation.w = 1.0

        # 初始化MoveIt2规划接口（适配Foxy）
        from moveit2 import MoveIt2
        arm_planner = MoveIt2(
            node=self,
            joint_names=["joint1","joint2","joint3","joint4","joint5","joint6"],
            base_link_name="arm_base",
            end_effector_link="tool_tip",
            group_name="arm_main_group"
        )
        # 限速，保证末端定位精度≤10mm
        arm_planner.set_max_velocity_scaling_factor(0.25)
        arm_planner.set_max_acceleration_scaling_factor(0.25)
        # 规划并执行轨迹
        ret_code = arm_planner.move_to_pose(target_pose)
        arm_planner.wait_until_executed()

        if ret_code == MoveItErrorCodes.SUCCESS:
            self.get_logger().info("✅ 巡检轨迹执行完成，定位达标")
        else:
            self.get_logger().error("❌ 轨迹执行失败，请检查机械臂模型与碰撞参数")
        # 单次运行后关闭定时器
        self.run_timer.cancel()

def main(args=None):
    rclpy.init(args=args)
    node = ArmTrajectoryNode()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == "__main__":
    main()
