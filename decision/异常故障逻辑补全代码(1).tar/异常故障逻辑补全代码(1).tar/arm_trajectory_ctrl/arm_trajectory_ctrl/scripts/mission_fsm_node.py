import rclpy
import math
from rclpy.node import Node

from std_msgs.msg import String
from geometry_msgs.msg import PointStamped, Twist, PoseStamped

class MissionFsmNode(Node):
    def __init__(self):
        super().__init__("mission_fsm_node")

        # 定义全部状态
        self.STATE_SEARCHING = "SEARCHING"
        self.STATE_TARGET_FOUND = "TARGET_FOUND"
        self.STATE_APPROACHING = "APPROACHING"
        self.STATE_BRUSHING = "BRUSHING"
        self.STATE_RETURNING = "RETURNING"
        self.STATE_ERROR = "ERROR"

        # 初始状态
        self.current_state = self.STATE_SEARCHING
        self.target_point = None

        # 任务5新增：视觉超时相关
        self.last_vision_time = self.get_clock().now()
        self.VISION_TIMEOUT = 3.0   # 3秒收不到视觉消息判定超时
        # 坐标合理范围，超出认为异常
        self.MAX_POS = 10.0

        # ----------订阅话题----------
        # 接收视觉3D目标坐标
        self.sub_vision_target = self.create_subscription(
            PointStamped,
            "/vision/target_point",
            self.callback_vision_target,
            10
        )
        # 复位指令订阅
        self.sub_reset = self.create_subscription(
            String,
            "/fsm/reset",
            self.callback_reset,
            10
        )

        # ----------发布话题----------
        self.pub_system_state = self.create_publisher(String, "/system/current_state",10)
        self.pub_uav_cmd_vel = self.create_publisher(Twist, "/uav/cmd_vel",10)
        self.pub_arm_target_pose = self.create_publisher(PoseStamped, "/arm/target_pose",10)

        # 定时器：100ms执行一次状态机逻辑
        self.timer = self.create_timer(0.1, self.fsm_loop)

        self.get_logger().info("业务状态机节点启动，初始状态：SEARCHING")

    def callback_vision_target(self, msg:PointStamped):
        """视觉目标点回调，保存目标坐标，增加异常坐标校验"""
        self.last_vision_time = self.get_clock().now()

        x = msg.point.x
        y = msg.point.y
        z = msg.point.z

        # 任务5：校验坐标是否NaN、无穷大、范围越界
        if math.isnan(x) or math.isnan(y) or math.isnan(z):
            self.get_logger().error("视觉坐标存在NaN异常，进入ERROR故障状态")
            self.current_state = self.STATE_ERROR
            return
        if abs(x) > self.MAX_POS or abs(y) > self.MAX_POS or abs(z) > self.MAX_POS:
            self.get_logger().error(f"视觉坐标越界 x={x:.2f},y={y:.2f},z={z:.2f}，进入ERROR故障状态")
            self.current_state = self.STATE_ERROR
            return

        self.target_point = msg
        self.get_logger().info(f"收到视觉目标点 x={msg.point.x:.2f}, y={msg.point.y:.2f}, z={msg.point.z:.2f}")

    def callback_reset(self, msg:String):
        if msg.data == "reset":
            self.reset_to_search()

    def reset_to_search(self):
        """复位函数，从ERROR恢复到SEARCHING"""
        self.target_point = None
        self.last_vision_time = self.get_clock().now()
        self.current_state = self.STATE_SEARCHING
        self.get_logger().info("故障复位，回到SEARCHING")

    def fsm_loop(self):
        """状态机主循环"""
        msg_state = String()
        msg_state.data = self.current_state
        self.pub_system_state.publish(msg_state)

        # =========任务5新增：视觉消息超时判断=========
        now = self.get_clock().now()
        vision_delta = (now - self.last_vision_time).nanoseconds / 1e9
        # 在作业流程中，如果超时，切ERROR
        if self.current_state in [self.STATE_TARGET_FOUND, self.STATE_APPROACHING, self.STATE_BRUSHING]:
            if vision_delta > self.VISION_TIMEOUT:
                self.get_logger().error(f"视觉消息超时{vision_delta:.1f}s，目标丢失，进入ERROR故障")
                self.current_state = self.STATE_ERROR
                return

        if self.current_state == self.STATE_SEARCHING:
            # 搜寻状态：等待目标点
            if self.target_point is not None:
                self.current_state = self.STATE_TARGET_FOUND
                self.get_logger().info("状态切换 --> TARGET_FOUND 识别到目标")

        elif self.current_state == self.STATE_TARGET_FOUND:
            # 识别到目标，切换靠近
            self.current_state = self.STATE_APPROACHING
            self.get_logger().info("状态切换 --> APPROACHING 开始靠近目标")

        elif self.current_state == self.STATE_APPROACHING:
            # 发布无人机前进速度指令
            twist = Twist()
            twist.linear.x = 0.2   # 向前飞
            self.pub_uav_cmd_vel.publish(twist)
            # 模拟：等待一小段时间之后认为无人机到位，切换刷拭
            self.current_state = self.STATE_BRUSHING
            self.get_logger().info("状态切换 --> BRUSHING 机械臂执行刷拭")

        elif self.current_state == self.STATE_BRUSHING:
            # 下发机械臂目标位姿
            arm_pose = PoseStamped()
            arm_pose.header.frame_id = "world"
            arm_pose.pose.position.x = self.target_point.point.x
            arm_pose.pose.position.y = self.target_point.point.y
            arm_pose.pose.position.z = self.target_point.point.z
            self.pub_arm_target_pose.publish(arm_pose)

            # 模拟刷拭完成，进入返航复位
            self.current_state = self.STATE_RETURNING
            self.get_logger().info("状态切换 --> RETURNING 作业完成，复位")

        elif self.current_state == self.STATE_RETURNING:
            # 清除目标，机械臂回到原点，回到搜寻状态
            self.target_point = None
            self.current_state = self.STATE_SEARCHING
            self.get_logger().info("状态切换 --> SEARCHING，等待下一次任务")

        elif self.current_state == self.STATE_ERROR:
            # 故障状态：全部输出置零，停止运动
            stop_twist = Twist()
            self.pub_uav_cmd_vel.publish(stop_twist)
            # ERROR状态不发布机械臂目标位姿，停止作业输出
            pass


def main(args=None):
    rclpy.init(args=args)
    node = MissionFsmNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("节点被手动关闭")
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()
