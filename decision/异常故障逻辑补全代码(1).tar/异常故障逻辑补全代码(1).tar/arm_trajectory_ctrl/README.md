# mission_fsm_node 海上运维业务状态机

## 故障异常处理
1. 视觉坐标NaN、非法数值：直接进入ERROR故障状态，停止所有输出指令。
2. 视觉消息超时（3s未收到目标点）：TARGET_FOUND/APPROACHING/BRUSHING作业状态下超时，进入ERROR故障。
3. ERROR状态行为：停止发布/uav/cmd_vel无人机速度，停止发布/arm/target_pose机械臂目标位姿。
4. 复位方式：向话题 /fsm/reset 发布 std_msgs/msg/String(data="reset")，即可从ERROR复位回到SEARCHING。

### 输入话题
- /vision/target_point    geometry_msgs/msg/PointStamped    视觉目标点
- /fsm/reset              std_msgs/msg/String              状态机复位指令

### 输出话题
- /system/current_state   std_msgs/msg/String     当前业务状态
- /uav/cmd_vel            geometry_msgs/msg/Twist 无人机速度指令
- /arm/target_pose        geometry_msgs/msg/PoseStamped 机械臂刷拭目标位姿
