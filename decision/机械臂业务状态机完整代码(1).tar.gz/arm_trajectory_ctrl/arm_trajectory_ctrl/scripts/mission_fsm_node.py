import rclpy
from rclpy.node import Node

from std_msgs.msg import String
from geometry_msgs.msg import PointStamped, Twist, PoseStamped

class MissionFsmNode(Node):
    def __init__(self):
        super().__init__("mission_fsm_node")

        # 定义全部状态
        self.STATE_SEARCHING = "SEARCHING"
        self.STATE_TARGET_FOUND = "TARGET_FOUND"
        self.STATE_APPROACHING = "APPROACHING"
        self.STATE_BRUSHING = "BRUSHING"
        self.STATE_RETURNING = "RETURNING"
        self.STATE_ERROR = "ERROR"

        # 初始状态
        self.current_state = self.STATE_SEARCHING
        self.target_point = None

        # ----------订阅话题----------
        # 接收视觉3D目标坐标
        self.sub_vision_target = self.create_subscription(
            PointStamped,
            "/vision/target_point",
            self.callback_vision_target,
            10
        )
        # =========新增：复位指令订阅==========
        self.sub_reset = self.create_subscription(
            String,
            "/fsm/reset",
            self.callback_reset,
            10
        )

        # ----------发布话题（严格遵守项目接口）----------
        self.pub_system_state = self.create_publisher(String, "/system/current_state",10)
        self.pub_uav_cmd_vel = self.create_publisher(Twist, "/uav/cmd_vel",10)
        self.pub_arm_target_pose = self.create_publisher(PoseStamped, "/arm/target_pose",10)

        # 定时器：100ms执行一次状态机逻辑
        self.timer = self.create_timer(0.1, self.fsm_loop)

        self.get_logger().info("业务状态机节点启动，初始状态：SEARCHING")

    def callback_vision_target(self, msg:PointStamped):
        """视觉目标点回调，保存目标坐标"""
        self.target_point = msg
        self.get_logger().info(f"收到视觉目标点 x={msg.pose.position.x:.2f}, y={msg.pose.position.y:.2f}, z={msg.pose.position.z:.2f}")

    # =========新增复位回调函数==========
    def callback_reset(self, msg:String):
        if msg.data == "reset":
            self.reset_to_search()

    def fsm_loop(self):
        """状态机主循环"""
        msg_state = String()
        msg_state.data = self.current_state
        self.pub_system_state.publish(msg_state)

        if self.current_state == self.STATE_SEARCHING:
            # 搜寻状态：等待目标点
            if self.target_point is not None:
                self.current_state = self.STATE_TARGET_FOUND
                self.get_logger().info("状态切换 --> TARGET_FOUND 识别到目标")

        elif self.current_state == self.STATE_TARGET_FOUND:
            # 识别到目标，切换靠近
            self.current_state = self.STATE_APPROACHING
            self.get_logger().info("状态切换 --> APPROACHING 开始靠近目标")

        elif self.current_state == self.STATE_APPROACHING:
            # 发布无人机前进速度指令
            twist = Twist()
            twist.linear.x = 0.2   # 向前飞
            self.pub_uav_cmd_vel.publish(twist)
            # 模拟：等待一小段时间之后认为无人机到位，切换刷拭
            # 真实项目这里需要根据坐标距离判断，本地测试先模拟
            self.current_state = self.STATE_BRUSHING
            self.get_logger().info("状态切换 --> BRUSHING 机械臂执行刷拭")

        elif self.current_state == self.STATE_BRUSHING:
            # 下发机械臂目标位姿
            arm_pose = PoseStamped()
            arm_pose.header.frame_id = "world"
            arm_pose.position.x = self.target_point.point.x
            arm_pose.position.y = self.target_point.point.y
            arm_pose.position.z = self.target_point.point.z
            self.pub_arm_target_pose.publish(arm_pose)

            # 模拟刷拭完成，进入返航复位
            self.current_state = self.STATE_RETURNING
            self.get_logger().info("状态切换 --> RETURNING 作业完成，复位")

        elif self.current_state == self.STATE_RETURNING:
            # 清除目标，机械臂回到原点，回到搜寻状态
            self.target_point = None
            self.current_state = self.STATE_SEARCHING
            self.get_logger().info("状态切换 --> SEARCHING，等待下一次任务")

        elif self.current_state == self.STATE_ERROR:
            # 故障状态：全部输出置零，停止运动
            stop_twist = Twist()
            self.pub_uav_cmd_vel.publish(stop_twist)

    def reset_to_search(self):
        """复位函数，从ERROR恢复到SEARCHING"""
        self.target_point = None
        self.current_state = self.STATE_SEARCHING
        self.get_logger().info("故障复位，回到SEARCHING")


def main(args=None):
    rclpy.init(args=args)
    node = MissionFsmNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("节点被手动关闭")
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()
